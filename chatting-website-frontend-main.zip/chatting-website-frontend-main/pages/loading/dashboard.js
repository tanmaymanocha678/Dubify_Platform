// particle js configuration
particlesJS.load("particles-js", "particlesjs-config.json");